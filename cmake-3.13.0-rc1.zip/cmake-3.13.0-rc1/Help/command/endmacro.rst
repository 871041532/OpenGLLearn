endmacro
--------

Ends a list of commands in a macro block.

::

  endmacro(expression)

See the :command:`macro` command.
