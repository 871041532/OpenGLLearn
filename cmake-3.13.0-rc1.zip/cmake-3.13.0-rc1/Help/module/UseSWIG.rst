.. cmake-module:: ../../Modules/UseSWIG.cmake
