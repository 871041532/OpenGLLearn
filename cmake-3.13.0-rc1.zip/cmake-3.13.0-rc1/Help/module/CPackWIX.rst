CPackWIX
--------

The documentation for the CPack WiX generator has moved here: :cpack_gen:`CPack WiX Generator`
