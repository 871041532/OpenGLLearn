.. cmake-module:: ../../Modules/FindMPEG.cmake
